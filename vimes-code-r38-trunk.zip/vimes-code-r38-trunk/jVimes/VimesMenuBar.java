import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class VimesMenuBar extends JMenuBar {

    public VimesMenuBar(ActionListener listener) {
 	// File Menu
 	JMenu fileMenu = new JMenu("File");
 	this.add(fileMenu);		
 	JMenuItem openMenuItem = new JMenuItem("Open");
 	openMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,
 							   ActionEvent.META_MASK));
 	fileMenu.add(openMenuItem);
 	openMenuItem.addActionListener(listener);

 	JMenuItem closeMenuItem = new JMenuItem("Close");
 	fileMenu.add(closeMenuItem);
 	closeMenuItem.addActionListener(listener);

 	JMenuItem quitMenuItem = new JMenuItem("Quit");
 	fileMenu.add(quitMenuItem);
 	quitMenuItem.addActionListener(listener);
 	quitMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q,
 							   ActionEvent.META_MASK));

 	// Edit Menu
 	JMenu editMenu = new JMenu("Edit");
 	this.add(editMenu);		
 	JMenuItem editMenuItem = new JMenuItem("Edit Structure");
 	editMenu.add(editMenuItem);
 	editMenuItem.addActionListener(listener);
 	editMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E,
 							   ActionEvent.META_MASK));

 	// Help Menu
 	JMenu helpMenu = new JMenu("Help");
 	this.add(helpMenu);		
 	//This doesn't work:
 	//this.setHelpMenu(helpMenu);
 	JMenuItem helpMenuItem = new JMenuItem("jVimes Help");
 	helpMenu.add(helpMenuItem);
 	helpMenuItem.addActionListener(listener);
 	helpMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_H,
 						       ActionEvent.META_MASK));
 	JMenuItem aboutMenuItem = new JMenuItem("About jVimes");
 	helpMenu.add(aboutMenuItem);
 	aboutMenuItem.addActionListener(listener);
 	aboutMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A,
 						       ActionEvent.META_MASK));



    }

}