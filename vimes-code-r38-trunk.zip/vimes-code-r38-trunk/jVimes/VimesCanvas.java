import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;

public class VimesCanvas extends JPanel {

    public void paintComponent(Graphics g){
	super.paintComponent(g);
	Graphics2D g2d = (Graphics2D)g;

	//setBackground(Color.BLACK);	
	//g.drawString("Hello",10,10);
	g.drawString(Util.symbol[5],15,15);
	g.drawString(Util.sym2no.get("Be").toString(),35,35);

    }

}