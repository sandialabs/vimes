
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Vimes implements ActionListener{
    
    public Vimes() {
	//Make sure we have nice window decorations.
        JFrame.setDefaultLookAndFeelDecorated(true);

        //Create and set up the window.
        JFrame frame = new JFrame("Vimes");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	VimesMenuBar menuBar = new VimesMenuBar(this);
	frame.setJMenuBar(menuBar);

	// Add a panel/canvas for the drawing here
	//JPanel canvas = new JPanel();
	VimesCanvas canvas = new VimesCanvas();
	canvas.setPreferredSize(new Dimension(300,300));
	frame.add(canvas);

	// Add a toolbar (to hold the animation buttons) here.
	JToolBar toolBar = new JToolBar();
	frame.add(toolBar,BorderLayout.SOUTH);
	JButton rewindButton = new JButton("<<");
	toolBar.add(rewindButton);
	JButton nextButton = new JButton(">");
	toolBar.add(nextButton);
	JButton playButton = new JButton(">>");
	toolBar.add(playButton);

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        JMenuItem source = (JMenuItem)(e.getSource());
	System.out.println("Action event detected, source: " + source.getText());
    }

    private static void createAndShowGUI() {
        Vimes vimes = new Vimes();
    }

    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
}