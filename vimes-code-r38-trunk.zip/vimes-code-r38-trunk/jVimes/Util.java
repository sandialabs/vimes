import java.util.Hashtable;

public class Util{

    // This module contains a series of utilities (programmed as
    // static methods and variables ), that simplify some aspects of
    // manipulating structures and atomic information.

    public static String [] symbol = {
	"X", "H", "He","Li","Be","B", "C", "N", "O", "F",
	"Ne","Na","Mg","Al","Si","P", "S", "Cl","Ar","K",
	"Ca","Sc","Ti","V", "Cr","Mn","Fe","Co","Ni","Cu",
	"Zn","Ga","Ge","As","Se","Br","Kr","Rb","Sr","Y",
	"Zr","Nb","Mo","Tc","Ru","Rh","Pd","Ag","Cd","In",
	"Sn","Sb","Te","I", "Xe","Cs","Ba","La","Ce","Pr",
	"Nd","Pm","Sm","Eu","Gd","Tb","Dy","Ho","Er","Tm",
	"Yb","Lu","Hf","Ta","W", "Re","Os","Ir","Pt","Au",
	"Hg","Tl","Pb","Bi","Po","At","Rn" };
 
    public static Hashtable sym2no = new Hashtable();
    static{
	for (int i=0; i<symbol.length; i++){
	    sym2no.put(symbol[i], new Integer(i));
	}
    }

}