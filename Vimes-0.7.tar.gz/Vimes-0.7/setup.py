"""\
Vimes: Visual Interface to Materials Simulation

Vimes is an open source package for visualizing materials and molecules.
"""

classifiers = """\
Development Status :: 3 - Alpha
Intended Audience :: Developers
Intended Audience :: Science/Research
License :: OSI Approved :: BSD License
Programming Language :: Python
Topic :: Scientific/Engineering
Topic :: Software Development :: Libraries :: Python Modules
Operating System :: Microsoft :: Windows
Operating System :: Unix
Operating System :: MacOS
"""

from distutils.core import setup

doclines = __doc__.split("\n")

setup(name="Vimes",
      version="0.7",
      description=doclines[0],
      long_description=__doc__,
      author = "Rick Muller",
      author_email = "rmuller@sandia.gov",
      url = "http://vimes.sourceforge.net",
      license = "GPL",
      platforms = ['any'],
      classifiers = filter(None,classifiers.split("\n")),
      packages = ["Vimes","Vimes.IO"],
      scripts = ["Scripts/RunVimes.py","Scripts/VimesInstallationTest.py"],
      )
      
